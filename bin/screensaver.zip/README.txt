Thank you for downloading the free Spanning Tree Corporation's tree-based screensaver!

This is shareware, feel free to pass it on! It was written by our resident C-dev, Kaito.
All credits go to him.

Usage:
Simply run "trees.scr" or configure it as your screensaver in Windows!

Optionally, you can configure it with command-line arguments:
./trees.scr <time_in_ms_between_tree_creation>

We have an open policy regarding user input! Surely you'd never do something evil with it.

(c) 2025, Spanning Tree Corporation